const loanForm = document.getElementById('loanForm');
const resultDiv = document.getElementById('result');

loanForm.addEventListener('submit', (event) => {
    event.preventDefault(); // Prevent form submission

    // Get form data
    const name = document.getElementById('name').value;
    const income = parseInt(document.getElementById('income').value);
    const loanAmount = parseInt(document.getElementById('loanAmount').value);
    const creditScore = parseInt(document.getElementById('creditScore').value);
    const loanPurpose = document.getElementById('loanPurpose').value;

    // Simulate loan approval logic
    const isApproved = (income > loanAmount * 2 && creditScore >= 600) || 
                       (loanPurpose === 'Home' && creditScore >= 700);

    // Display result
    if (isApproved) {
        resultDiv.textContent = 'Loan Approved!';
        resultDiv.classList.add('approved');
    } else {
        resultDiv.textContent = 'Loan Rejected!';
        resultDiv.classList.add('rejected');
    }

    // Clear form after submission
    loanForm.reset();
});
