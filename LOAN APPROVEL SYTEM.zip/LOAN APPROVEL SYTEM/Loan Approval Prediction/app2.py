import pandas as pd
import streamlit as st
from sklearn.preprocessing import StandardScaler
import pickle as pk

st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

    /* Ensure the background covers the full viewport */
    .stApp {
        background: linear-gradient(-45deg, #4CAF50, #2ECC71, #FFD700, #16A085);
        background-size: 400% 400%;
        animation: gradientBackground 15s ease infinite;
        font-family: 'Poppins', sans-serif;
        color: #333;
    }

    @keyframes gradientBackground {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }

    /* Main container styling */
    .main-container {
        background-color: rgba(255, 255, 255, 0.9);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0px 0px 30px rgba(0, 0, 0, 0.2);
        width: 100%;
        max-width: 800px;
        margin: 20px auto;
        text-align: center;
        animation: fadeIn 2s ease-out;
    }

    h1 {
        font-size: 2.8rem;
        color: #333;
        margin-bottom: 20px;
    }

    p, label {
        font-size: 1.2rem;
        color: #666;
    }

    .stButton>button {
        background-color: #FF5722;
        color: #fff;
        font-size: 1.2rem;
        font-weight: 600;
        padding: 10px;
        border-radius: 5px;
        border: none;
        transition: background-color 0.3s ease;
    }

    .stButton>button:hover {
        background-color: #E64A19;
    }

    @keyframes fadeIn {
        0% { opacity: 0; }
        100% { opacity: 1; }
    }
    </style>
    """, unsafe_allow_html=True)


st.title("Loan Approval Prediction App")
st.write("Upload a CSV file to predict loan approval status.")


model = pk.load(open('model.pkl', 'rb'))
scaler = pk.load(open('scaler.pkl', 'rb'))


def process_data(df):
    df['Assets'] = df['residential_assets_value'] + df['commercial_assets_value'] + df['luxury_assets_value'] + df['bank_asset_value']
    df.drop(columns=['residential_assets_value', 'commercial_assets_value', 'luxury_assets_value', 'bank_asset_value'], inplace=True)
    

    df['education'] = df['education'].str.strip().replace(['Graduate', 'Not Graduate'], [1, 0])
    

    df['self_employed'] = df['self_employed'].str.strip().replace(['No', 'Yes'], [0, 1])
    
    return df


uploaded_file = st.file_uploader("Upload CSV", type=['csv'])
if uploaded_file is not None:
    st.write("Processing the uploaded file...")
    
    data = pd.read_csv(uploaded_file)
    st.write("Uploaded CSV Data:", data.head())  
    
    
    data_clean = process_data(data)
    
    
    input_data = data_clean[['no_of_dependents', 'education', 'self_employed', 'income_annum', 'loan_amount', 'loan_term', 'cibil_score', 'Assets']]
    
    
    input_data_scaled = scaler.transform(input_data)
    
    
    predictions = model.predict(input_data_scaled)
    
    
    predictions = ['Accepted' if pred == 1 else 'Rejected' for pred in predictions]
    
    
    data['loan_status_prediction'] = predictions
    
    
    result_filename = "loan_approval_results.csv"
    data.to_csv(result_filename, index=False)
    
    
    st.write("Updated Data with Predictions:", data)
    
    
    st.download_button(label="Download Predictions", data=data.to_csv(index=False), file_name=result_filename)

else:
    st.write("Please upload a CSV file to continue.")
