import streamlit as st
import pandas as pd
import pickle as pk


model = pk.load(open('model.pkl', 'rb'))
scaler = pk.load(open('scaler.pkl', 'rb'))


st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

    /* Ensure the background covers the full viewport */
    .stApp {
/* Updated Gradient */
background: linear-gradient(-45deg, #4CAF50, #2ECC71, #FFD700, #16A085);
        background-size: 400% 400%;
        animation: gradientBackground 15s ease infinite;
        font-family: 'Poppins', sans-serif;
        color: #333;
    }


    @keyframes gradientBackground {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
    }

    /* Main container styling */
    .main-container {
        background-color: rgba(255, 255, 255, 0.9);
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0px 0px 30px rgba(0, 0, 0, 0.2);
        width: 100%;
        max-width: 800px;
        margin: 20px auto;
        text-align: center;
        animation: fadeIn 2s ease-out;
    }

    h1 {
        font-size: 2.8rem;
        color: #333;
        margin-bottom: 20px;
    }

    p, label {
        font-size: 1.2rem;
        color: #666;
    }

    .stSlider {
        margin-bottom: 25px;
    }

    .stButton>button {
        background-color: #FF5722;
        color: #fff;
        font-size: 1.2rem;
        font-weight: 600;
        padding: 10px;
        border-radius: 5px;
        border: none;
        transition: background-color 0.3s ease;
    }

    .stButton>button:hover {
        background-color: #E64A19;
    }

    @keyframes fadeIn {
        0% { opacity: 0; }
        100% { opacity: 1; }
    }
    </style>
    """, unsafe_allow_html=True)


st.header('Loan Prediction App')
st.write("Our system provides accurate loan approval predictions based on customer data.")


no_of_dep = st.slider('Choose No of Dependents', 0, 5)
grad = st.selectbox('Choose Education', ['Graduated', 'Not Graduated'])
self_emp = st.selectbox('Self-Employed?', ['Yes', 'No'])
Annual_Income = st.slider('Choose Annual Income', 0, 10000000)
Loan_Amount = st.slider('Choose Loan Amount', 0, 10000000)
Loan_Dur = st.slider('Choose Loan Duration (Years)', 0, 20)
Cibil = st.slider('Choose CIBIL Score', 0, 1000)
Assets = st.slider('Choose Assets Value', 0, 10000000)


grad_s = 0 if grad == 'Graduated' else 1
emp_s = 0 if self_emp == 'No' else 1

if st.button("Predict"):
    pred_data = pd.DataFrame([[no_of_dep, grad_s, emp_s, Annual_Income, Loan_Amount, Loan_Dur, Cibil, Assets]],
                             columns=['no_of_dependents', 'education', 'self_employed', 'income_annum', 'loan_amount', 'loan_term', 'cibil_score', 'Assets'])
    pred_data = scaler.transform(pred_data)
    predict = model.predict(pred_data)
    
    if predict[0] == 1:
        st.success('Loan Is Approved')
    else:
        st.error('Loan Is Rejected')


st.markdown("</div>", unsafe_allow_html=True)
